package Modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

public class proyecto {
	
	private String nombre;
	private String descripcion;
	private String fechaInicial;
	private String fechaFinal;
	private String tipo;
	private ArrayList<actividad> actividades;
	private usuario principal;
	private ArrayList<usuario> usuariosSec = new ArrayList<usuario>();
	
	
	public proyecto(String nom, String desc, String fechIn, String fechFin, String tip, usuario usu) {
		
		nombre = nom;
		descripcion = desc;
		fechaInicial = fechIn;
		fechaFinal = fechFin;
		setTipo(tip);
		principal = usu;
		ArrayList<actividad> act= new ArrayList<actividad>();
		setActividades(act);
		ArrayList<usuario> usuariosSec = new ArrayList<usuario>();
		setusuariosSec(usuariosSec);
	}
	
// Get y Set
	
	
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public usuario getPrincipal() {
		return principal;
	}

	public void setPrincipal(usuario principal) {
		this.principal = principal;
	}
	
	public String darNombre() {
		return nombre;
	}
	
	public ArrayList<actividad> darListaActividades() {
		return actividades;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public ArrayList<actividad> getActividades() {
		return actividades;
	}

	public void setActividades(ArrayList<actividad> actividades) {
		this.actividades = actividades;
	}
	
	public ArrayList<usuario> usuariosSec() {
		return usuariosSec;
	}

	public void setusuariosSec(ArrayList<usuario> usuariosSec) {
		this.usuariosSec = usuariosSec;
	}
	 
	
	// avances del proyecto
	public String darAvanceProyecto() throws ParseException {
		
		//
		int num_actividades = actividades.size();
		int acti_terminadas = 0;
		int acti_proceso = 0;
		String retorno_final = "";
		
		for(actividad act : actividades) {
			
			boolean finalizo = (act.getHoraTotal() !=0);
			if(finalizo) {
				acti_terminadas += 1;
			}
			else {
				acti_proceso += 1;
			}
		}
		String fecha_actual = input("ingrese la fecha actual en el formato: dd/MM/yyyy");
		
		
		
		SimpleDateFormat sdformat = new SimpleDateFormat("dd/MM/yyyy");
		
		
		Date initial = sdformat.parse(fecha_actual);
	    Date fechaFinalaa = sdformat.parse(fechaFinal);
	    
	    
	    
	    if(initial.compareTo(fechaFinalaa) > 0) {
	    	retorno_final += "El proyecto esta desfasado en el tiempo estimado, ";
	      } else if(initial.compareTo(fechaFinalaa) <= 0) {
	         System.out.println("EL proyecto sigue a tiempo, ");
	      }
	    
	    retorno_final += "y de las " + String.valueOf(num_actividades) + "totales se han completado " + String.valueOf(acti_terminadas);
	
		return retorno_final;
	}
	
	// Se da la informacion acerca del equipo en este proyecto
	public String datosEquipo() {
		
		
		String retorno_final = "";
		int tiempo_total_equipo = 0;
		for(usuario usu :usuariosSec) {
			
			
			retorno_final += usu.DarNombre();
			retorno_final += ":" + usu.generarReportePart() + ",";
			
			tiempo_total_equipo += usu.DarTiempo_total_inv();
			
		}
		
		retorno_final += "//" + "el tiempo total invertido por el equipo es de: " + String.valueOf(tiempo_total_equipo);
		return retorno_final;
	}
	
	
// Procesos
	
	private String input(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void agregarActividad(actividad activity) 
	{
		this.actividades.add(activity);
	}
	
	public void agregarUsuarioSec(usuario usu) {
		
		
		if(usuariosSec.contains(usu) == false) {
	
			this.usuariosSec.add(usu);
		}
		
	}
	
	public String generarReporteTxt() {
		
		String texto1 = "nombreProy: " + nombre + "\nDescripcion: " + descripcion + "\nTipo: " + tipo + "\nFechaIni: " + 
		fechaInicial + "\nFechaFin: " + fechaFinal + "\n\nUsuario Principal\n\n";
		
		String texto2 = "UsuarioPrin: " + principal.DarNombre() + "\nCorreoPrin: " + principal.DarCorreo();
		
		String texto3 = "\n\nUsuarios Secundarios\n\n";
		
		for(usuario x: usuariosSec) {
			
			String textoMom = "Usuario: " + x.DarNombre() + "\nCorreo: " + x.DarCorreo();
			texto3 = texto3.concat(textoMom);
		}
		
		return texto1+texto2+texto3;
	}
	
	// reportes tiempo promedio
	public float darReporteTiemposPromedio()
	{
		Integer n = this.actividades.size();
		Integer tiempo = 0;
		
		for(int x=0 ; x < n ; x++) 
		{
			tiempo+=actividades.get(x).getHoraTotal();
		}
		
		float tiempo_promedio= tiempo/n;
	
		return tiempo_promedio;
	}
	
}