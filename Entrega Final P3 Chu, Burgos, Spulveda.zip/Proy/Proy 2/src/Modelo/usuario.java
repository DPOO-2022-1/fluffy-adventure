package Modelo;

import java.util.ArrayList;

public class usuario {
	
	public String nombre;
	public String correo;
	private ArrayList<actividad> Actividades_Realizadas;
	public int tiempo_total_inv = 0;
	
	public usuario(String t1, String t2) {
		
		nombre = t1;
		correo = t2;
	}
	
	public String DarNombre() {
		return nombre;
	}
	
	public String DarCorreo() {
		return correo;
	}
	
	public int DarTiempo_total_inv() {
		return tiempo_total_inv;
	}
	
	public String DarInfo(){
		
		String texto = "nombre: " + nombre + "\ncorreo: " + correo + "";
		
		return texto;
	}
	
	public void anadirActividad(actividad act) {
		this.Actividades_Realizadas.add(act);
	}
	
	
	 // reporte por participante
	public String generarReportePart() {
		
		int tiem_Total_invertido =  0;
		int tiem_Prom_Actividad =  0;
		int num_actividades = Actividades_Realizadas.size();
		
		
		for(actividad act : Actividades_Realizadas) {
			
			boolean finalizo = (act.getHoraTotal() !=0);
			
			
			if(finalizo) {
				tiem_Total_invertido += act.getHoraTotal();
			}
			
			}
		tiempo_total_inv += tiem_Total_invertido;
		tiem_Prom_Actividad = tiem_Total_invertido/num_actividades;
			
		
		return "Tiempo Total Invertido = " + String.valueOf(tiem_Total_invertido) + "; Tiempo Promedio por actividad = " + String.valueOf(tiem_Prom_Actividad);
	}
	
}