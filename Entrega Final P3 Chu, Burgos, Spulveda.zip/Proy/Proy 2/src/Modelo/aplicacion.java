package Modelo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class aplicacion {
	
	private usuario usuarioActual;
	private proyecto proyectoActual = null;
	private ArrayList<proyecto> proyectos = new ArrayList<proyecto>();
	
	public aplicacion(String nom, String cor) {
		
		this.usuarioActual = new usuario(nom, cor);
		
	}
	
	// metodos procesos
	
	public void Menu() {
		
		boolean continuar = true;
		while (continuar) {
			ImprimirMenu();
			int opcion = Integer.parseInt(input("Elige una opcion: \n"));
			
			if (opcion == 1) {
				
				crearProyecto();
			}
			else if (opcion == 2){
				
				crearActividad();
			} 
			else if (opcion == 3) {
				
				System.out.println("El tiempo promedio por actividad es de: " + this.proyectoActual.darReporteTiemposPromedio());
			}
			else if (opcion == 0){
				
				continuar = false;
				
			}
			
			
		}
		
	}
	
	public void crearActividad() {
		
		actividad actividad= new actividad("", "", "", "", "",this.usuarioActual);
		
		if(proyectoActual == null) 
		{
			System.out.println("*ERROR*\n No hay un proyecto activo, por favor cargue un proyecto o cree uno nuevo para agregar una nueva actividad.");
		}
		else
		{
			String nombre = input("Ingrese el nombre de la actividad:\n");
			actividad.setTitulo(nombre);
			String descripcion = input("Ingrese una descripci�n para la actividad:\n");
			actividad.setDescripcion(descripcion);
			
			
			
			String fechaIn = input("Digite la fecha de inicio de la actividad:\n");
			actividad.setFecha_inicial(fechaIn);
			
			String es_pasada = input("Digite 1 si la actividad ya fue concluida y tiene una fecha final, 0 si la actividad esta activa en este momento");
			if( es_pasada == "1 ") {
				
				String fechaFin = input("Digite la fecha de final de la actividad:\n");
				actividad.setFecha_final(fechaFin);
			}
			else{
				String fechaFin = "";
				actividad.setFecha_final(fechaFin);
			}
			
			String tipo = input("Digite el tipo de actividad que se realiza:\n");
			actividad.setTipo(tipo);
			System.out.println("Por defecto el usuario que realiza la actividad es el usuario actual �Desea cambiar el usuario que la realiza?\n");
			String cambio= input("(S/N):\n");
			if(cambio.equals("S")) 
			{
				String nusuario = input("Digite el nombre del usuario: \n");
				String cusuario = input("Digite el correo del usuario: \n");
				usuario nuevo = new usuario(nusuario, cusuario);
				actividad.setCreador(nuevo);
				nuevo.anadirActividad(actividad);
				proyectoActual.agregarUsuarioSec(nuevo);
			}
			else 
			{
				actividad.setCreador(this.usuarioActual);
				proyectoActual.agregarUsuarioSec(this.usuarioActual);
				usuarioActual.anadirActividad(actividad);
			}
			
			proyectoActual.agregarActividad(actividad);
			
			
		}
		}
	
	public void cambiarProyecto() {
		
		String proy = input("Ingrese el nombre del proyecto al que se va a cambiar\n");
		boolean proyecto_exist = false;
		
		for(proyecto proyectito : proyectos) {
			
			String nombre_proyecto = proyectito.getNombre();
			if( nombre_proyecto == proy) {
				proyecto_exist = true;
				proyectoActual = proyectito;
			}	
		}
		
		if(proyecto_exist == false) {
			
			System.out.println("No Existe un proyecto con dicho nombre, intente con otro");
		}
		
		
		
	}
		
	public void agregarUsuarioCon(usuario us) {
		
		String nombre_usu_sec = input("Ingrese el nombre del participante\n");
		String correo_usu_sec = input("Ingrese el correo del participante\n");
		
		us = new usuario(nombre_usu_sec,correo_usu_sec);
		
		proyectoActual.agregarUsuarioSec(us); 
		
	}
	
	public void generarReporteParticipante(usuario us) {
		
		
		
		String reporte = us.generarReportePart();
	}
	
	
	public void crearProyecto() {

		
		String nombre = input("Ingrese el nombre del proyecto:\n");
		String descripcion = input("Ingrese la descripcion del proyecto:\n");
		String fechaInicio = input("Ingrese la fecha inicial del proyecto:\n");
		usuario duenio = usuarioActual;
		String fechaFinEstimada = input("Ingrese la fecha final estimada del proyecto:\n");
		String tipo = input("Ingrese el tipo del proyecto:");
		
		proyectoActual = new proyecto(nombre, descripcion, fechaInicio, fechaFinEstimada, tipo, duenio);
		
		proyectos.add(proyectoActual);
		
		
	}
	
	// crear participante se usara para anadir proyectos a nombre de otra persona, se una opcion que realize esto a la hora de crear una nueva actividad
	public void crearParticipante() {
		
		String nombre = input("Ingrese el nombre del proyecto:\n");
		String correo = input("Ingrese la descripcion del proyecto:\n");
		
		usuario participante = new usuario(nombre,correo);
		
	}
	
	// Metodos Imprimir
	
	public String ImprimirInfoUsuario() {
		return usuarioActual.DarInfo();
	}
	
	public void ImprimirMenu() {
		
		if (proyectoActual == null) {
			
			System.out.println("\nNo hay proyecto activo \n");
			
		} else {
			
			System.out.println("\nEl proyecto actual es: " + proyectoActual.darNombre());
			
		}	
		
		System.out.println("1) Crear nuevo proyecto");
		
		System.out.println("2) Agregar una actividad al proyecto actual:");
		
		System.out.println("3) Dar tiempo promedio por actividad en el proyecto actual:");
		
		System.out.println("0) Cerrar App");
	}
	
	// Propio de la app
	
	
	private String input(String string) {
		
		try{
		
		System.out.println(string);
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		return reader.readLine();
		}
		catch(IOException e) {
			
			System.out.println("Error leyendo");
			e.printStackTrace();
		}
		return null;
	}
	
	
	// Metodos P2

}
