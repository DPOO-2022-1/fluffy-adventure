module Proy_2 {
	requires java.desktop;
}